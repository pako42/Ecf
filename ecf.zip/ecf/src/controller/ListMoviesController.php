<?php

class ListMoviesController
{
    private $title;
    private $model;
    private $listMovies;

    public function __construct()

    {
        $this->title = "Mes films";
        $this->model = new Model();
    }

    function manage() {

        $this->listMovies = $this->model->getAllMovie();
        
        include (__DIR__ . "./../view/listMovies.php");
    }

}