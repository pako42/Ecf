<?php

class HomeController
{
    private $title;

    public function __construct()
    {
        $this->title = "Comme au ciné !";
    }

    function manage() {

        include (__DIR__ . "./../view/home.php");
    }
}
