<?php

class SearchMovieController
{
    private $title;
    private $model;

    public function __construct()
    {
        $this->title = "Rechercher un film";
        $this->model = new Model ();
    }

    function manage() {

        if (isset($_POST['title']) != '') {

            $this->model->getSearchMovies($_POST['title']);        

        }

        include (__DIR__ . "./../view/searchMovies.php");
    }
}
