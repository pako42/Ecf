<?php

include (__DIR__ ."./../view/header.php");
?>

<div class="logo">
<img src="./src/public/img/popcorn.png" alt="Boîte de Pop Corn du cinéma">

</div>

<?php

include (__DIR__ ."./../view/footer.php");