<?php


class Model
{

    private $handle;

    public function __construct()
    {
        $db = DbAcces::getInstance();
        $this->handle = $db->getHandle();
    }

    public function addNewMovie($title, $poster, $year) {

        try {

            $request = $this->handle->prepare('INSERT INTO films (id, url_film, year_product_film)
                                                VALUES (?,?,?)');

            $request->execute(array(
                $title,
                $poster,
                $year,
            ));

        } catch (PDOException $e) {
            var_dump('Erreur lors de la requete SQL :' . $e->getMessage());
        }
    }

    public function getAllMovie() {

        try {

            $request = $this->handle->prepare('SELECT * FROM films ');
            $request->execute();

            $data = $request->fetchAll();

            return $data;

        } catch (PDOException $e) {
            var_dump('Erreur lors de la requete SQL : ' . $e->getMessage());
        }
    }

    public function getSearchMovies() {

        try {

            $request = $this->handle->prepare('SELECT * FROM films ');
            $request->execute();

            $data = $request->fetchAll();

            return $data;

        } catch (PDOException $e) {
            var_dump('Erreur lors de la requete SQL : ' . $e->getMessage());
        }
    }




}